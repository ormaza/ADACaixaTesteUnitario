Para instalar os pacotes, rode o seguinte comando, apontando para a pasta onde o .nupkg foi colocado (para a PASTA, não para o arquivo diretamente). Sigam o exemplo abaixo (substituindo o nome do pacote em questão - no exemplo, nsubstitute)

dotnet add package nsubstitute --source /minhapastadepkgs